﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UTS_PBO.Core;


namespace UTS_PBO.Controller
{
    internal class InventarisContext : DatabaseWrapper
    {
        private string table = "inventaris";
        public static DataTable All()
        {
            string query = @"SELECT m.id, m.nama, m.kategori, m.jumlah, m.harga";

            DataTable dataInventaris = queryExecutor(query);
            return dataInventaris;
        }
       
    }
}
